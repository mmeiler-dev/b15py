from enum import IntEnum

class Channel(IntEnum):
    Channel0 = 0,
    Channel1 = 1,
    Channel2 = 2,
    Channel3 = 3,
    Channel4 = 4,
    Channel5 = 5,
    Channel6 = 6,
    Channel7 = 7


Channel0 = Channel.Channel0
Channel1 = Channel.Channel1
Channel2 = Channel.Channel2
Channel3 = Channel.Channel3
Channel4 = Channel.Channel4
Channel5 = Channel.Channel5
Channel6 = Channel.Channel6
Channel7 = Channel.Channel7
