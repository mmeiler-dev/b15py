from enum import IntEnum

class Port(IntEnum):
    Port0 = 0
    Port1 = 1

Port0 = Port.Port0
Port1 = Port.Port1